
#include <stdio.h>
#include <omp.h>

int main()
{

  printf("I think");

  printf(" car");

  printf(" race");

  printf("s are fun\n");

}
